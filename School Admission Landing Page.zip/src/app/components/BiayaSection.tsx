import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";
import { Badge } from "./ui/badge";
import { CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

export function BiayaSection() {
  const fees = [
    {
      title: "Biaya Pendaftaran",
      amount: "Rp 500.000",
      description: "Biaya pendaftaran tidak dapat dikembalikan",
      badge: "Sekali Bayar",
    },
    {
      title: "Biaya Masuk",
      amount: "Rp 15.000.000",
      description: "Termasuk seragam, buku paket, dan dana pengembangan",
      badge: "Sekali Bayar",
    },
    {
      title: "SPP Bulanan",
      amount: "Rp 2.500.000/bulan",
      description: "Sudah termasuk biaya kegiatan ekstrakurikuler",
      badge: "Setiap Bulan",
    },
    {
      title: "Biaya Tahunan",
      amount: "Rp 3.000.000/tahun",
      description: "Untuk kegiatan study tour, praktikum, dan ujian",
      badge: "Setiap Tahun",
    },
  ];

  const faqs = [
    {
      question: "Apakah ada program cicilan untuk biaya masuk?",
      answer: "Ya, kami menyediakan program cicilan untuk biaya masuk hingga 3 kali pembayaran tanpa bunga. Cicilan pertama dibayarkan saat daftar ulang, cicilan kedua sebulan setelahnya, dan cicilan ketiga dua bulan setelah daftar ulang.",
    },
    {
      question: "Apakah ada potongan biaya untuk saudara kandung?",
      answer: "Ya, kami memberikan diskon 10% untuk biaya SPP bulanan bagi siswa yang memiliki saudara kandung yang juga bersekolah di SMA Harapan Bangsa.",
    },
    {
      question: "Apa saja yang termasuk dalam biaya tahunan?",
      answer: "Biaya tahunan mencakup kegiatan study tour, praktikum laboratorium, ujian semester, ujian akhir, serta pemeliharaan fasilitas dan buku perpustakaan.",
    },
    {
      question: "Apakah ada beasiswa yang tersedia?",
      answer: "Ya, kami menyediakan beasiswa prestasi akademik dan non-akademik untuk siswa berprestasi. Beasiswa dapat mencakup hingga 50% dari total biaya SPP selama satu tahun pelajaran. Informasi lebih lanjut dapat ditanyakan saat pendaftaran.",
    },
    {
      question: "Bagaimana cara pembayaran SPP?",
      answer: "Pembayaran SPP dapat dilakukan melalui transfer bank, virtual account, atau langsung di bagian keuangan sekolah. SPP harus dibayarkan setiap tanggal 1-10 setiap bulannya.",
    },
    {
      question: "Apakah biaya dapat berubah sewaktu-waktu?",
      answer: "Biaya yang sudah ditetapkan di awal tahun ajaran tidak akan berubah selama tahun ajaran tersebut. Perubahan biaya hanya akan diberlakukan untuk tahun ajaran berikutnya dengan pemberitahuan terlebih dahulu.",
    },
  ];

  return (
    <section id="biaya" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Informasi Biaya Pendidikan
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Investasi terbaik untuk masa depan anak Anda dengan biaya yang transparan dan kompetitif
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {fees.map((fee, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow border-t-4 border-blue-600">
                <CardHeader>
                  <Badge className="w-fit mb-2 bg-blue-100 text-blue-700">
                    {fee.badge}
                  </Badge>
                  <CardTitle className="text-lg">{fee.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-blue-600 mb-4">{fee.amount}</p>
                  <p className="text-sm text-gray-600">{fee.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <Card className="bg-gradient-to-r from-blue-50 to-green-50">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                Yang Sudah Termasuk dalam Biaya:
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  "Seragam lengkap (2 stel)",
                  "Buku paket pelajaran",
                  "Akses perpustakaan digital",
                  "Fasilitas laboratorium",
                  "Ekstrakurikuler pilihan",
                  "Konseling dan bimbingan",
                  "Asuransi kesehatan siswa",
                  "Wifi dan akses e-learning",
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* FAQ Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Pertanyaan yang Sering Diajukan (FAQ)
          </h3>
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-lg px-6 border">
                <AccordionTrigger className="text-left hover:no-underline">
                  <span className="font-semibold text-gray-900">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
