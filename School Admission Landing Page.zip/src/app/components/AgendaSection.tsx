import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Calendar, ClipboardCheck, FileCheck, Bell } from "lucide-react";
import { motion } from "motion/react";

export function AgendaSection() {
  const timeline = [
    {
      icon: <Bell className="w-8 h-8 text-blue-600" />,
      title: "Pembukaan Pendaftaran",
      date: "1 Mei 2026 - 30 Juni 2026",
      description: "Pendaftaran dibuka untuk calon siswa baru tahun ajaran 2026/2027",
      status: "Upcoming",
    },
    {
      icon: <ClipboardCheck className="w-8 h-8 text-blue-600" />,
      title: "Ujian Seleksi",
      date: "5 Juli 2026 - 10 Juli 2026",
      description: "Tes tertulis meliputi Matematika, Bahasa Indonesia, Bahasa Inggris, dan IPA",
      status: "Upcoming",
    },
    {
      icon: <FileCheck className="w-8 h-8 text-blue-600" />,
      title: "Pengumuman Hasil Seleksi",
      date: "15 Juli 2026",
      description: "Pengumuman dapat dilihat melalui website dan nomor pendaftaran",
      status: "Upcoming",
    },
    {
      icon: <Calendar className="w-8 h-8 text-blue-600" />,
      title: "Daftar Ulang",
      date: "20 Juli 2026 - 30 Juli 2026",
      description: "Peserta yang lulus wajib melakukan daftar ulang dan melengkapi berkas",
      status: "Upcoming",
    },
  ];

  const importantDates = [
    {
      event: "Batas Akhir Pendaftaran Online",
      date: "30 Juni 2026",
      color: "bg-red-100 text-red-700",
    },
    {
      event: "Pengumpulan Berkas Administrasi",
      date: "1 Juli 2026",
      color: "bg-orange-100 text-orange-700",
    },
    {
      event: "Tes Kesehatan",
      date: "11 Juli 2026",
      color: "bg-yellow-100 text-yellow-700",
    },
    {
      event: "Wawancara Orang Tua & Siswa",
      date: "12-13 Juli 2026",
      color: "bg-green-100 text-green-700",
    },
    {
      event: "Masa Orientasi Siswa (MOS)",
      date: "1-5 Agustus 2026",
      color: "bg-blue-100 text-blue-700",
    },
    {
      event: "Tahun Ajaran Baru Dimulai",
      date: "8 Agustus 2026",
      color: "bg-purple-100 text-purple-700",
    },
  ];

  return (
    <section id="agenda" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Agenda PSB 2026/2027
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Catat tanggal-tanggal penting berikut agar tidak melewatkan tahapan pendaftaran
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto mb-16">
          <div className="relative">
            {/* Vertical Line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-blue-200 hidden md:block"></div>

            <div className="space-y-8">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="relative"
                >
                  <Card className="ml-0 md:ml-20 hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="absolute -left-4 md:left-4 top-6 bg-white p-2 rounded-full border-4 border-blue-200">
                          {item.icon}
                        </div>
                        <div className="ml-16 md:ml-0 flex-1">
                          <div className="flex flex-wrap items-center gap-3 mb-2">
                            <h3 className="text-xl font-semibold text-gray-900">
                              {item.title}
                            </h3>
                            <Badge className="bg-blue-100 text-blue-700">
                              {item.status}
                            </Badge>
                          </div>
                          <p className="text-blue-600 font-medium mb-2">{item.date}</p>
                          <p className="text-gray-600">{item.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Important Dates Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Tanggal Penting Lainnya
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {importantDates.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                viewport={{ once: true }}
              >
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-gray-400" />
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900 text-sm mb-1">
                          {item.event}
                        </p>
                        <Badge className={`${item.color} text-xs`}>
                          {item.date}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Notice */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-12"
        >
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Bell className="w-5 h-5 text-blue-600" />
                Catatan Penting
              </h4>
              <ul className="text-gray-700 space-y-2 ml-7">
                <li>• Peserta yang tidak hadir pada hari ujian seleksi dianggap mengundurkan diri</li>
                <li>• Pengumuman hasil seleksi juga akan dikirimkan melalui email dan SMS</li>
                <li>• Peserta yang lulus wajib melakukan daftar ulang sesuai jadwal yang ditentukan</li>
                <li>• Keterlambatan daftar ulang dapat mengakibatkan pembatalan kelulusan</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
