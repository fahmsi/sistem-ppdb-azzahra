import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { GraduationCap, Calendar, Star, Users, BookOpen, Globe, Microscope, Music } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";

export function ProgramSection() {
  const [activeTestimoni, setActiveTestimoni] = useState(0);

  const programs = [
    {
      icon: <GraduationCap className="w-8 h-8 text-blue-600" />,
      title: "Kelas Akselerasi",
      description: "Program percepatan untuk siswa berprestasi dengan kurikulum yang disesuaikan.",
    },
    {
      icon: <Globe className="w-8 h-8 text-blue-600" />,
      title: "Bilingual Class",
      description: "Pembelajaran dwi bahasa untuk persiapan pendidikan internasional.",
    },
    {
      icon: <Microscope className="w-8 h-8 text-blue-600" />,
      title: "STEM Program",
      description: "Fokus pada Science, Technology, Engineering, dan Mathematics.",
    },
    {
      icon: <Music className="w-8 h-8 text-blue-600" />,
      title: "Ekstrakurikuler",
      description: "Lebih dari 20 pilihan ekskul untuk mengembangkan bakat dan minat.",
    },
  ];

  const achievements = [
    {
      image: "https://images.unsplash.com/photo-1659080907377-ee6a57fb6b9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwYWNoaWV2ZW1lbnQlMjB0cm9waHl8ZW58MXx8fHwxNzc2MjM3NzE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Juara 1 Olimpiade Matematika Nasional 2025",
      level: "Nasional",
    },
    {
      image: "https://images.unsplash.com/photo-1659080907377-ee6a57fb6b9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwYWNoaWV2ZW1lbnQlMjB0cm9waHl8ZW58MXx8fHwxNzc2MjM3NzE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Medali Emas Kompetisi Sains Internasional",
      level: "Internasional",
    },
    {
      image: "https://images.unsplash.com/photo-1659080907377-ee6a57fb6b9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwYWNoaWV2ZW1lbnQlMjB0cm9waHl8ZW58MXx8fHwxNzc2MjM3NzE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      title: "Juara Umum Lomba Karya Tulis Ilmiah",
      level: "Provinsi",
    },
  ];

  const testimonials = [
    {
      name: "Andi Pratama",
      role: "Siswa Kelas 12",
      message: "Sekolah ini memberikan saya kesempatan untuk berkembang tidak hanya secara akademik, tapi juga karakter dan soft skill yang sangat berguna.",
      image: "https://images.unsplash.com/photo-1561346745-5db62ae43861?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGFzaWFuJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzc2MjM3NzE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Siti Nurhaliza",
      role: "Siswa Kelas 11",
      message: "Guru-guru di sini sangat berdedikasi dan fasilitas belajarnya sangat lengkap. Saya merasa sangat terbantu dalam memahami pelajaran.",
      image: "https://images.unsplash.com/photo-1561346745-5db62ae43861?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGFzaWFuJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzc2MjM3NzE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
  ];

  const parentTestimonials = [
    {
      name: "Ibu Maria Wijaya",
      role: "Orang Tua Siswa",
      message: "Saya sangat puas dengan perkembangan anak saya di sekolah ini. Komunikasi dengan pihak sekolah sangat baik dan transparan.",
      image: "https://images.unsplash.com/photo-1728138127500-fb73c1313f76?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJlbnRzJTIwdGVhY2hlciUyMG1lZXRpbmd8ZW58MXx8fHwxNzc2MjM3NzE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Bapak Ahmad Santoso",
      role: "Orang Tua Siswa",
      message: "Investasi terbaik untuk masa depan anak. Sekolah ini benar-benar memperhatikan perkembangan setiap siswa secara individual.",
      image: "https://images.unsplash.com/photo-1728138127500-fb73c1313f76?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJlbnRzJTIwdGVhY2hlciUyMG1lZXRpbmd8ZW58MXx8fHwxNzc2MjM3NzE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
  ];

  const facilities = [
    {
      icon: <BookOpen className="w-6 h-6 text-green-600" />,
      title: "Perpustakaan Digital",
      image: "https://images.unsplash.com/photo-1770721666603-ff87f3c2ed04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2hvb2wlMjBsaWJyYXJ5JTIwZmFjaWxpdHl8ZW58MXx8fHwxNzc2MjM3NzE2fDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      icon: <Microscope className="w-6 h-6 text-green-600" />,
      title: "Laboratorium Sains",
      image: "https://images.unsplash.com/photo-1636386689060-37d233b5d345?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2llbmNlJTIwbGFib3JhdG9yeSUyMHNjaG9vbHxlbnwxfHx8fDE3NzYyMzc3MTd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      icon: <Users className="w-6 h-6 text-green-600" />,
      title: "Lapangan Olahraga",
      image: "https://images.unsplash.com/photo-1759200135568-566eb9ecaa81?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2hvb2wlMjBzcG9ydHMlMjBmYWNpbGl0aWVzfGVufDF8fHx8MTc3NjIzNzcxN3ww&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      icon: <Calendar className="w-6 h-6 text-green-600" />,
      title: "Ruang Kelas Modern",
      image: "https://images.unsplash.com/photo-1606761568499-6d2451b23c66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50cyUyMHN0dWR5aW5nJTIwY2xhc3Nyb29tfGVufDF8fHx8MTc3NjIxMDk1MHww&ixlib=rb-4.1.0&q=80&w=1080",
    },
  ];

  return (
    <section id="program" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Programs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-center text-gray-900 mb-4">
            Program Unggulan Kami
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Berbagai program berkualitas yang dirancang untuk mengembangkan potensi akademik dan non-akademik siswa
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {programs.map((program, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4">{program.icon}</div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {program.title}
                  </h3>
                  <p className="text-gray-600 text-sm">{program.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Prestasi Siswa
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {achievements.map((achievement, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-shadow">
                  <img
                    src={achievement.image}
                    alt={achievement.title}
                    className="w-full h-48 object-cover"
                  />
                  <CardContent className="p-6">
                    <Badge className="mb-3 bg-blue-100 text-blue-700">
                      {achievement.level}
                    </Badge>
                    <h4 className="font-semibold text-gray-900">{achievement.title}</h4>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Student Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Testimoni Siswa
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-500 mb-3">{testimonial.role}</p>
                      <p className="text-gray-600 italic">"{testimonial.message}"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* Parent Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Testimoni Orang Tua
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {parentTestimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-500 mb-3">{testimonial.role}</p>
                      <p className="text-gray-600 italic">"{testimonial.message}"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* Facilities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Fasilitas Sekolah
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {facilities.map((facility, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                  <img
                    src={facility.image}
                    alt={facility.title}
                    className="w-full h-40 object-cover"
                  />
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      {facility.icon}
                      <h4 className="font-semibold text-gray-900">{facility.title}</h4>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
