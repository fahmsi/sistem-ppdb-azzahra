import { Card, CardContent } from "./ui/card";
import { CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

export function PersyaratanSection() {
  const requirements = [
    "Fotokopi Ijazah/Surat Keterangan Lulus (Legalisir) - 2 lembar",
    "Fotokopi SKHUN (Legalisir) - 2 lembar",
    "Fotokopi Rapor SMP/MTs semester 1-6 - 1 set",
    "Fotokopi Kartu Keluarga - 2 lembar",
    "Fotokopi Akta Kelahiran - 2 lembar",
    "Fotokopi KTP Orang Tua - 2 lembar",
    "Pas Foto berwarna ukuran 3x4 (latar belakang merah) - 4 lembar",
    "Pas Foto berwarna ukuran 4x6 (latar belakang biru) - 2 lembar",
    "Surat Keterangan Sehat dari Dokter",
    "Surat Keterangan Kelakuan Baik dari Sekolah",
    "Mengisi formulir pendaftaran online",
    "Membayar biaya pendaftaran",
  ];

  return (
    <section id="persyaratan" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Persyaratan Administrasi
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Pastikan semua dokumen di bawah ini sudah disiapkan dengan lengkap sebelum melakukan pendaftaran
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <Card>
            <CardContent className="p-8">
              <div className="space-y-4">
                {requirements.map((requirement, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                    viewport={{ once: true }}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700">{requirement}</p>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8 p-6 bg-blue-50 rounded-lg border-l-4 border-blue-600">
                <h4 className="font-semibold text-gray-900 mb-2">Catatan Penting:</h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Semua dokumen harus asli dan masih berlaku</li>
                  <li>• Fotokopi yang diminta harus jelas dan terbaca</li>
                  <li>• Dokumen yang sudah diserahkan tidak dapat dikembalikan</li>
                  <li>• Berkas yang tidak lengkap tidak akan diproses</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
