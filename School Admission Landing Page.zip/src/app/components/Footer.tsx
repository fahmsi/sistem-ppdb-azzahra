import { Facebook, Instagram, Twitter, Youtube, Mail, Phone } from "lucide-react";

export function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const quickLinks = [
    { label: "Home", id: "home" },
    { label: "Program", id: "program" },
    { label: "Persyaratan", id: "persyaratan" },
    { label: "Biaya", id: "biaya" },
    { label: "Agenda PSB", id: "agenda" },
    { label: "Kontak", id: "kontak" },
  ];

  const socialMedia = [
    { icon: <Facebook className="w-5 h-5" />, label: "Facebook", href: "#" },
    { icon: <Instagram className="w-5 h-5" />, label: "Instagram", href: "#" },
    { icon: <Twitter className="w-5 h-5" />, label: "Twitter", href: "#" },
    { icon: <Youtube className="w-5 h-5" />, label: "YouTube", href: "#" },
  ];

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* School Info */}
          <div>
            <h3 className="text-white text-xl font-semibold mb-4">
              SMA Harapan Bangsa
            </h3>
            <p className="text-sm mb-4">
              Membentuk generasi unggul dengan karakter kuat dan prestasi gemilang untuk masa depan Indonesia yang lebih baik.
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Mail className="w-4 h-4" />
                <span>info@smaharapanbangsa.sch.id</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="w-4 h-4" />
                <span>(021) 1234-5678</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Menu Cepat</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="text-sm hover:text-white transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Programs */}
          <div>
            <h4 className="text-white font-semibold mb-4">Program Unggulan</h4>
            <ul className="space-y-2 text-sm">
              <li>Kelas Akselerasi</li>
              <li>Bilingual Class</li>
              <li>STEM Program</li>
              <li>Ekstrakurikuler</li>
              <li>Persiapan PTN/PTS</li>
              <li>International Class</li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h4 className="text-white font-semibold mb-4">Ikuti Kami</h4>
            <p className="text-sm mb-4">
              Dapatkan informasi terbaru tentang kegiatan dan prestasi sekolah kami
            </p>
            <div className="flex gap-3">
              {socialMedia.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="bg-gray-800 p-2 rounded-full hover:bg-blue-600 transition-colors"
                  aria-label={social.label}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-center md:text-left">
              © 2026 SMA Harapan Bangsa. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <button className="hover:text-white transition-colors">
                Kebijakan Privasi
              </button>
              <button className="hover:text-white transition-colors">
                Syarat & Ketentuan
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
