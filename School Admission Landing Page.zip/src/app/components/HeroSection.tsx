import { Button } from "./ui/button";
import { motion } from "motion/react";

export function HeroSection() {
  const scrollToKontak = () => {
    const element = document.getElementById("kontak");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative bg-gradient-to-br from-blue-50 to-green-50 py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Wujudkan Masa Depan Cemerlang Bersama Kami
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Bergabunglah dengan SMA Harapan Bangsa, institusi pendidikan yang telah mencetak
              generasi unggul dengan prestasi akademik dan karakter yang kuat. Kami berkomitmen
              memberikan pendidikan terbaik untuk masa depan anak Anda.
            </p>
            <Button
              onClick={scrollToKontak}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg"
            >
              Daftar Sekarang
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <img
              src="https://images.unsplash.com/photo-1775369406135-4f2540f29d0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzY2hvb2wlMjBidWlsZGluZyUyMGVkdWNhdGlvbnxlbnwxfHx8fDE3NzYyMzc3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Modern School Building"
              className="rounded-2xl shadow-2xl w-full h-auto"
            />
          </motion.div>
        </div>

        {/* Video Profile Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-20"
        >
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
            Profil Sekolah Kami
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="relative pb-[56.25%] h-0 overflow-hidden rounded-xl shadow-xl bg-gray-200">
              <iframe
                className="absolute top-0 left-0 w-full h-full"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ"
                title="School Profile Video"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
