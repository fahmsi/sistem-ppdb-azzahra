import { Building2, Trophy, BookOpen, Trees } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { motion } from "motion/react";

export function QuickHighlights() {
  const highlights = [
    {
      icon: <Building2 className="w-12 h-12 text-blue-600" />,
      title: "Fasilitas Modern",
      description: "Ruang kelas ber-AC, laboratorium lengkap, dan perpustakaan digital yang mendukung pembelajaran optimal.",
    },
    {
      icon: <Trophy className="w-12 h-12 text-blue-600" />,
      title: "Prestasi Gemilang",
      description: "Juara olimpiade nasional dan internasional dalam berbagai bidang akademik dan non-akademik.",
    },
    {
      icon: <BookOpen className="w-12 h-12 text-blue-600" />,
      title: "Program Unggulan",
      description: "Kelas akselerasi, program bilingual, dan persiapan perguruan tinggi terkemuka di dalam dan luar negeri.",
    },
    {
      icon: <Trees className="w-12 h-12 text-blue-600" />,
      title: "Lingkungan Kondusif",
      description: "Suasana belajar yang nyaman, hijau, dan aman dengan pengawasan ketat untuk kenyamanan siswa.",
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4">{item.icon}</div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {item.title}
                  </h3>
                  <p className="text-gray-600">{item.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
