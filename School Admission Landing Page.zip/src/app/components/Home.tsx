import { HeroSection } from "./HeroSection";
import { QuickHighlights } from "./QuickHighlights";
import { ProgramSection } from "./ProgramSection";
import { PersyaratanSection } from "./PersyaratanSection";
import { BiayaSection } from "./BiayaSection";
import { AgendaSection } from "./AgendaSection";
import { KontakSection } from "./KontakSection";

export function Home() {
  return (
    <div>
      <HeroSection />
      <QuickHighlights />
      <ProgramSection />
      <PersyaratanSection />
      <BiayaSection />
      <AgendaSection />
      <KontakSection />
    </div>
  );
}
